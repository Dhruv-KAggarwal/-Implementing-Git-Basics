const fs = require('fs');
const path = require('path');

function readCSV(filePath) {
  if (!fs.existsSync(filePath)) return [];
  const data = fs.readFileSync(filePath, 'utf8').trim();
  if (!data) return [];
  const [header, ...lines] = data.split('\n');
  const keys = header.split(',');
  return lines.map(line => {
    const values = line.split(',');
    return Object.fromEntries(keys.map((k, i) => [k.trim(), values[i]?.trim()]));
  });
}

function writeCSV(filePath, data) {
  if (!data.length) return;
  const keys = Object.keys(data[0]);
  const lines = [keys.join(','), ...data.map(row => keys.map(k => row[k]).join(','))];
  fs.writeFileSync(filePath, lines.join('\n'), 'utf8');
}

function appendCSV(filePath, row) {
  const exists = fs.existsSync(filePath);
  const line = Object.values(row).join(',');
  fs.appendFileSync(filePath, (exists ? '\n' : '') + line, 'utf8');
}

module.exports = { readCSV, writeCSV, appendCSV };