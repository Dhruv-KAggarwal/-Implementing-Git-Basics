const routes = {
  '/dashboard': 'dashboard.html',
  '/reports': 'reports.html',
  '/patients': 'patients.html',
  '/appointments': 'appointments.html',
  '/profile': 'profile.html'
};

function setActiveNav(route) {
  document.querySelectorAll('nav a').forEach(a => a.classList.remove('active'));
  const navId = 'nav-' + (route.replace('/', '') || 'dashboard');
  const nav = document.getElementById(navId);
  if (nav) nav.classList.add('active');
}

async function loadPage(route) {
  const file = routes[route] || 'dashboard.html';
  try {
    const res = await fetch(file);
    if (!res.ok) throw new Error('Page not found');
    const html = await res.text();
    const main = document.getElementById('main-content');
    main.classList.add('fade-out');
    setTimeout(() => {
      main.innerHTML = html;
      main.classList.remove('fade-out');
      main.classList.add('fade-in');
      setTimeout(() => main.classList.remove('fade-in'), 300);
      setActiveNav(route);
    }, 300);
  } catch (err) {
    console.error(err);
    document.getElementById('main-content').innerHTML = '<h2>Page not found</h2>';
  }
}

window.addEventListener('hashchange', () => {
  loadPage(location.hash.replace('#', '') || '/dashboard');
});
window.addEventListener('DOMContentLoaded', () => {
  loadPage(location.hash.replace('#', '') || '/dashboard');
  document.getElementById('logoutBtn').onclick = () => {
    sessionStorage.removeItem('user');
    window.location.href = 'login.html';
  };
});