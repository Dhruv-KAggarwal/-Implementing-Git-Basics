const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const USERS_CSV = path.join(__dirname, '..', 'users.csv');

// Helper: Generate unique MED ID
function generateMedId() {
    return 'MED' + Math.floor(100000 + Math.random() * 900000);
}

// Helper: Read users.csv and parse
function readUsers() {
    if (!fs.existsSync(USERS_CSV)) return [];
    const data = fs.readFileSync(USERS_CSV, 'utf8').trim();
    if (!data) return [];
    return data.split('\n').map(line => {
        const [id, name, email, password, role] = line.split(',');
        return { id, name, email, password, role };
    });
}

// Helper: Write users to users.csv
function writeUsers(users) {
    const data = users.map(user => `${user.id},${user.name},${user.email},${user.password},${user.role}`).join('\n');
    fs.writeFileSync(USERS_CSV, data, 'utf8');
}

// Register route
router.post('/register', (req, res) => {
    const { name, email, password, role } = req.body;
    if (!name || !email || !password || !role) {
        return res.status(400).json({ error: 'All fields are required.' });
    }

    const users = readUsers();
    if (users.some(user => user.email === email)) {
        return res.status(400).json({ error: 'Email already exists.' });
    }

    const newUser = {
        id: generateMedId(),
        name,
        email,
        password,
        role
    };
    users.push(newUser);
    writeUsers(users);

    res.json({ message: 'Registration successful.', user: newUser });
});

// Login route
router.post('/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required.' });
    }

    const users = readUsers();
    const user = users.find(user => user.email === email && user.password === password);

    if (!user) {
        return res.status(401).json({ error: 'Invalid email or password.' });
    }

    res.json({ message: 'Login successful.', user });
});

module.exports = router;
