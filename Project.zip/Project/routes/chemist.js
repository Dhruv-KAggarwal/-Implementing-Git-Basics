const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const STOCK_CSV = path.join(__dirname, '..', 'stock.csv');

// Helper: Read stock.csv and parse
function readStock() {
    if (!fs.existsSync(STOCK_CSV)) return [];
    const data = fs.readFileSync(STOCK_CSV, 'utf8').trim();
    if (!data) return [];
    return data.split('\n').slice(1).map(line => {
        const [medicineName, quantity] = line.split(',');
        return { medicineName, quantity: parseInt(quantity, 10) };
    });
}

// Helper: Write stock to stock.csv
function writeStock(stock) {
    const data = ['Medicine Name,Quantity', ...stock.map(item => `${item.medicineName},${item.quantity}`)].join('\n');
    fs.writeFileSync(STOCK_CSV, data, 'utf8');
}

// Update stock
router.post('/updateStock', (req, res) => {
    const { medicineName, quantity } = req.body;
    if (!medicineName || quantity == null) {
        return res.status(400).json({ error: 'Medicine name and quantity are required.' });
    }

    const stock = readStock();
    const existingItem = stock.find(item => item.medicineName === medicineName);

    if (existingItem) {
        existingItem.quantity += quantity; // Update quantity
    } else {
        stock.push({ medicineName, quantity }); // Add new medicine
    }

    writeStock(stock);
    res.json({ message: 'Stock updated successfully.' });
});

// Sell medicine (deduct stock)
router.post('/sellMedicine', (req, res) => {
    const { medicineName, quantity } = req.body;
    if (!medicineName || quantity == null) {
        return res.status(400).json({ error: 'Medicine name and quantity are required.' });
    }

    const stock = readStock();
    const existingItem = stock.find(item => item.medicineName === medicineName);

    if (!existingItem || existingItem.quantity < quantity) {
        return res.status(400).json({ error: 'Insufficient stock.' });
    }

    existingItem.quantity -= quantity; // Deduct quantity
    writeStock(stock);
    res.json({ message: 'Medicine sold successfully.' });
});

module.exports = router;