const express = require('express');
const { readCSV } = require('../utils/csv');
const path = require('path');
const router = express.Router();

const REPORTS_CSV = path.join(__dirname, '..', 'reports.csv');

router.get('/', (req, res) => {
  const reports = readCSV(REPORTS_CSV);
  res.json(reports);
});

// Valid route with a parameter
router.get('/api/user/:id', (req, res) => {
  res.send(`User ID: ${req.params.id}`);
});

// Valid route without parameters
router.get('/api/users', (req, res) => {
  res.send('All users');
});

module.exports = router;